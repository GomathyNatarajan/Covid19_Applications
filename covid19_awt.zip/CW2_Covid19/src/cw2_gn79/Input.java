package cw2_gn79;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Data;
import bean.Output;

public class Input extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter out = res.getWriter();
		
		String region = req.getParameter("region");
		String country = req.getParameter("country");
		String date_from = req.getParameter("datefrom");
		String date_to = req.getParameter("dateto");
		
		Output dbOperator = new Output();
		List<Data> d;
		d = dbOperator.FetchDetails(region,country,date_from, date_to);
		HttpSession se = req.getSession();

		if (d != null) {
			se.setAttribute("Data", d);
			res.sendRedirect("../Output.jsp");
		} else {
			res.sendRedirect("../Input.jsp");
			out.close();
		}
		
		
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
}
