package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.security.*;
import java.math.*;

public class Output {

	private static Connection connect = null;
	private static String host = "localhost";
	private static String database = "AWT";
	private static String username = "root";
	private static String password = "Positive";

	public static Connection getConnection() {
		if (connect == null) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				String conn_string = "jdbc:mysql://" + host + "/" + database;
				Connection connect = DriverManager.getConnection(conn_string, username, password);
				return connect;
			} catch (Exception ex) {
				return null;
				// ex.printStackTrace();
			}
		} else {
			return connect;
		}
	}

	public List<Data> FetchDetails(String region, String country, String date_from, String date_to) {
		ArrayList<Data> d = new ArrayList<Data>();

		String sql = "SELECT * from covid19 WHERE continent=? AND location=? AND date BETWEEN ? AND ?";

		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql);) {
			
			pstmt.setString(1, region);
			pstmt.setString(2, country);
			pstmt.setString(3, date_from);
			pstmt.setString(4, date_to);

			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					
					String r = rs.getString(2);
					String c = rs.getString(3);
					String dt = rs.getString(4);
					String tc = rs.getString(5);
					String nc = rs.getString(6);
					String td = rs.getString(8);
					String nd = rs.getString(9);
					
					d.add(new Data(r, c, dt, tc, nc, td, nd));
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		return d;
	}
}
