package bean;

public class Data {

	public String getRegion() {
		return region;
	}
	public String getCountry() {
		return country;
	}
	public String getDate() {
		return date;
	}
	public String getTotal_cases() {
		return total_cases;
	}
	public String getNew_cases() {
		return new_cases;
	}
	public String getTotal_deaths() {
		return total_deaths;
	}
	public String getNew_deaths() {
		return new_deaths;
	}
	
	public  void  setRegion(String region) {
		this.region = region;
	}
	public void  setCountry(String country) {
		this.country = country;
	}
	public void  setDate(String date) {
		this.date = date;
	}
	public void  setTotal_cases(String total_cases) {
		this.total_cases = total_cases;
	}
	public void  setNew_cases(String new_cases) {
		this.new_cases = new_cases;
	}
	public void setTotal_deaths(String total_deaths) {
		this.total_deaths = total_deaths;
	}
	public void setNew_deaths(String new_deaths) {
		this.new_deaths = new_deaths;
	}
	
	
	public Data(String region,
	String country,
	String date,
	String total_cases,
	String new_cases,
	String total_deaths,
	String new_deaths) {
		super();
		this.region = region;
		this.country = country;
		this.date = date;
		this.total_cases = total_cases;
		this.new_cases = new_cases;
		this.total_deaths = total_deaths;
		this.new_deaths = new_deaths;
		
	}
	String region;
	String country;
	String date;
	String total_cases;
	String new_cases;
	String total_deaths;
	String new_deaths;
}
